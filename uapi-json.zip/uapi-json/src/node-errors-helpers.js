const nodeErrorsHelpers = require('node-errors-helpers')('uapi-json');

module.exports = nodeErrorsHelpers;
