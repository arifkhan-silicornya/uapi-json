module.exports = {
  Validation: 400,
  Unauthenticated: 401,
  Unauthorized: 403,
  NotFound: 404,
  UapiFailure: 598,
  GdsFailure: 599,
};
