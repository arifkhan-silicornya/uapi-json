const closeSession = require('./TERMINAL_CLOSE_SESSION.handlebars');
const createSession = require('./TERMINAL_CREATE_SESSION.handlebars');
const request = require('./TERMINAL_REQUEST.handlebars');

module.exports = {
  closeSession,
  createSession,
  request,
};
