const currencyConversion = require('./UTILS_CURRENCY_CONVERSION.handlebars');
const referenceData = require('./UTILS_REFERENCE_DATA_RETRIVE.handlebars');

module.exports = {
  currencyConversion,
  referenceData
};
