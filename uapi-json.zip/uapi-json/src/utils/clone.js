module.exports = obj => JSON.parse(JSON.stringify(obj));
