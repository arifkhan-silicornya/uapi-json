module.exports = obj => obj && obj[Object.keys(obj)[0]];
